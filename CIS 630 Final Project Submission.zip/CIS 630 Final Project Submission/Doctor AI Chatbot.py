import os
os.environ["STREAMLIT_WATCHER_TYPE"] = "none"

import streamlit as st
import torch
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    pipeline
)

# -------------------------
# Title
# -------------------------
st.title("🤖🩺 AI Doctor Chatbot – Fine-Tuning LoRA Adapters Only")
st.markdown("Efficient LoRA adapter fine-tuning on a medical dataset using Streamlit.")

# -------------------------
# Step 1: Load Tokenizer & Model (cached)
# -------------------------
@st.cache_resource
def load_model_and_tokenizer():
    model = AutoModelForCausalLM.from_pretrained("aboonaji/llama2finetune-v2")
    model.config.use_cache = False
    model.config.pretraining_tp = 1

    # Freeze everything except LoRA adapters
    for name, param in model.named_parameters():
        if "lora" not in name.lower():
            param.requires_grad = False
        else:
            param.requires_grad = True

    tokenizer = AutoTokenizer.from_pretrained("aboonaji/llama2finetune-v2", trust_remote_code=True)
    tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"
    return model, tokenizer

with st.spinner("🔄 Loading model and tokenizer..."):
    llama_model, llama_tokenizer = load_model_and_tokenizer()
st.success("✅ Model & Tokenizer Ready")

# -------------------------
# Step 2: Tokenize & Cache Dataset
# -------------------------
@st.cache_data
def load_tokenized_dataset():
    dataset = load_dataset("aboonaji/wiki_medical_terms_llam2_format", split="train")

    def tokenize(batch):
        tokens = llama_tokenizer(batch["text"], padding="max_length", truncation=True, max_length=256)
        tokens["labels"] = tokens["input_ids"].copy()
        return tokens

    tokenized = dataset.map(tokenize, batched=True)
    tokenized.set_format(type="torch", columns=["input_ids", "attention_mask", "labels"])
    return tokenized

with st.spinner("📦 Loading and tokenizing dataset..."):
    train_dataset = load_tokenized_dataset()
st.success("✅ Dataset Tokenized")

# -------------------------
# Step 3: Training Arguments
# -------------------------
training_arguments = TrainingArguments(
    output_dir="./results",
    per_device_train_batch_size=4,
    max_steps=100,
    save_strategy="no",
    optim="adamw_torch",
    remove_unused_columns=False
)

# -------------------------
# Step 4: Fine-Tuning Trigger
# -------------------------
st.markdown("## Step 4: Fine-Tune the Model (Optional)")

if st.button("🚀 Start Fine-Tuning"):
    with st.spinner("Fine-tuning LoRA adapters..."):
        trainer = Trainer(
            model=llama_model,
            args=training_arguments,
            train_dataset=train_dataset,
            tokenizer=llama_tokenizer,
        )
        trainer.train()
    st.success("✅ Fine-tuning completed!")

# -------------------------
# Step 5: Chatting with the Model
# -------------------------
st.markdown("## Step 5: Ask the AI Doctor")

user_prompt = st.text_area("✍️ Describe symptoms or ask a question:", "Persistent headache and dizziness")

if st.button("💬 Get Response"):
    with st.spinner("Generating medical advice..."):
        text_generation_pipeline = pipeline(
            task="text-generation",
            model=llama_model,
            tokenizer=llama_tokenizer,
            max_length=300
        )
        response = text_generation_pipeline(f"<s>[INST] {user_prompt} [/INST]")
    st.subheader("🧠 Model's Answer:")
    st.success(response[0]['generated_text'])
